package com.example.clientapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    TextView output;
    Socket s;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        output=findViewById(R.id.output);
    }

    public void connectionActivity(View view){
        try {
            output.setText("Processing");
            s=new Socket();
            output.setText("socket made");
            s.connect(new InetSocketAddress("192.168.43.210",5090),5000);
            output.setText("Connected");
        } catch (Exception e) {
            output.setText("Unable to connect");
        }


    }
}
